package com.stcino.ai

import com.stcino.ai.core.AppMatcher
import com.stcino.ai.core.Match
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppMatcherTest {
    private val apps = listOf("YouTube", "YouTube Music", "Chrome", "Settings", "Calculator")
    private fun m(q: String) = AppMatcher.match(q, apps) { it }

    @Test fun exactWins() = assertEquals(Match.One("YouTube"), m("youtube"))
    @Test fun aliasWorks() = assertEquals(Match.One("YouTube"), m("yt"))
    @Test fun uniquePartial() = assertEquals(Match.One("Calculator"), m("calc"))
    @Test fun ambiguousAsksUser() = assertTrue(m("you") is Match.Many<*>)
    @Test fun missing() = assertEquals(Match.None, m("nonexistent app"))
}
