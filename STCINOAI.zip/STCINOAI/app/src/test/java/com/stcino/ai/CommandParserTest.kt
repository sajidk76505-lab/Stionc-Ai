package com.stcino.ai

import com.stcino.ai.core.Command
import com.stcino.ai.core.CommandParser
import com.stcino.ai.data.Lang
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {
    private val name = "STCINO AI"
    private fun p(s: String) = CommandParser.parse(s, name)

    @Test fun openWithWakeWord() = assertEquals(Command.OpenApp("youtube"), p("Hey STCINO, open YouTube."))
    @Test fun openHinglish() = assertEquals(Command.OpenApp("chrome"), p("Chrome open karo"))
    @Test fun openHindi() = assertEquals(Command.OpenApp("youtube"), p("youtube खोलो"))
    @Test fun searchIsYoutube() = assertEquals(Command.YouTube("gta v gameplay"), p("STCINO, search GTA V gameplay"))
    @Test fun playOnYoutube() = assertEquals(Command.YouTube("arijit singh songs"), p("Play Arijit Singh songs on YouTube"))
    @Test fun hinglishYoutube() = assertEquals(Command.YouTube("arijit singh"), p("youtube pe arijit singh chalao"))
    @Test fun languageSwitch() = assertEquals(Command.SetLanguage(Lang.HINDI), p("STCINO, Hindi mein jawab do"))
    @Test fun codingGoesToAi() = assertTrue(p("STCINO, mujhe Python ka code likhkar do") is Command.Chat)
    @Test fun longStartSentenceIsChat() = assertTrue(p("start learning python from basics today please") is Command.Chat)
}
