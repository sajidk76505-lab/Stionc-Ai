package com.stcino.ai

import com.stcino.ai.ai.AiResult
import com.stcino.ai.ai.ErrKind
import com.stcino.ai.ai.GeminiParser
import com.stcino.ai.core.TextTools
import com.stcino.ai.core.Validators
import com.stcino.ai.core.YouTube
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HelpersTest {
    @Test fun youtubeUrlEncoded() {
        assertEquals("https://www.youtube.com/results?search_query=arijit+singh", YouTube.searchUrl("arijit singh"))
        assertTrue(YouTube.searchUrl("a&b").endsWith("a%26b"))
    }

    @Test fun segmentsSplitCode() {
        val s = TextTools.segments("hello ```python\nprint(1)\n``` bye")
        assertEquals(3, s.size)
        assertTrue(s[1].code)
        assertEquals("python", s[1].lang)
        assertEquals("print(1)", s[1].text)
    }

    @Test fun speechCleanerRemovesCodeAndMarkdown() {
        val out = TextTools.forSpeech("Hi **there** ```kotlin\nval x=1\n``` ok")
        assertFalse(out.contains("val x"))
        assertFalse(out.contains("*"))
        assertFalse(out.contains("`"))
    }

    @Test fun nameValidation() {
        assertEquals("Jarvis AI", Validators.assistantName("  Jarvis AI<script> "))
        assertEquals(Validators.DEFAULT_NAME, Validators.assistantName("   "))
        assertEquals(24, Validators.assistantName("x".repeat(100)).length)
    }

    @Test fun apiKeyValidationAndMask() {
        assertNull(Validators.apiKey("short"))
        assertNull(Validators.apiKey("has space in the key 1234567890"))
        val k = "AIzaSyA1234567890abcdefghijklmnop"
        assertNotNull(Validators.apiKey(k))
        assertFalse(Validators.mask(k).contains("1234567890abcdef"))
    }

    @Test fun modelValidation() {
        assertEquals("gemini-2.5-flash", Validators.model("models/gemini-2.5-flash"))
        assertNull(Validators.model("bad/model?x=1"))
    }

    @Test fun geminiTextParsing() {
        val ok = GeminiParser.parseText("""{"candidates":[{"content":{"parts":[{"text":"Hello"}]}}]}""")
        assertEquals(AiResult.Ok("Hello"), ok)
        val blocked = GeminiParser.parseText("""{"promptFeedback":{"blockReason":"SAFETY"}}""")
        assertTrue(blocked is AiResult.Err)
        assertTrue(GeminiParser.parseText("not json") is AiResult.Err)
    }

    @Test fun geminiModelParsing() {
        val body = """{"models":[{"name":"models/gemini-x","supportedGenerationMethods":["generateContent"]},
            {"name":"models/embed","supportedGenerationMethods":["embedContent"]}]}"""
        assertEquals(AiResult.Ok(listOf("gemini-x")), GeminiParser.parseModels(body))
    }

    @Test fun httpErrorMapping() {
        assertEquals(ErrKind.RATE_LIMIT, GeminiParser.httpError(429, "").kind)
        assertEquals(ErrKind.INVALID_KEY, GeminiParser.httpError(400, "API key not valid").kind)
        assertEquals(ErrKind.INVALID_KEY, GeminiParser.httpError(403, "").kind)
        assertEquals(ErrKind.SERVER, GeminiParser.httpError(503, "").kind)
    }
}
