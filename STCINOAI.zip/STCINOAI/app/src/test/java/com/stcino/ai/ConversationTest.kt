package com.stcino.ai

import com.stcino.ai.data.ChatMsg
import com.stcino.ai.data.Conversation
import org.junit.Assert.assertEquals
import org.junit.Test

class ConversationTest {
    @Test fun jsonRoundTrip() {
        val c = Conversation("id-1", "Title", 123L, listOf(ChatMsg("user", "hi", 1L), ChatMsg("model", "hello \"quoted\"\nline2", 2L)))
        assertEquals(c, Conversation.fromJson(c.toJson()))
    }
}
