package com.stcino.ai.data

import org.json.JSONArray
import org.json.JSONObject

enum class Personality(val id: String, val label: String) {
    FRIENDLY("friendly", "Friendly Assistant"),
    JARVIS("jarvis", "Professional Jarvis"),
    COMPANION("companion", "Female Companion"),
    DEVELOPER("developer", "Developer Assistant"),
    CUSTOM("custom", "Custom Personality");

    companion object {
        fun fromId(id: String?): Personality = values().firstOrNull { it.id == id } ?: FRIENDLY
    }
}

enum class Lang(val id: String, val label: String, val speechTag: String) {
    HINGLISH("hinglish", "Hinglish", "hi-IN"),
    HINDI("hindi", "हिन्दी (Hindi)", "hi-IN"),
    ENGLISH("english", "English", "en-IN");

    companion object {
        fun fromId(id: String?): Lang = values().firstOrNull { it.id == id } ?: HINGLISH
    }
}

/** All user-configurable settings. The API key is NOT here; it lives encrypted (see SecureKey). */
data class Settings(
    val loaded: Boolean = false,
    val assistantName: String = "STCINO AI",
    val personality: Personality = Personality.FRIENDLY,
    val customPrompt: String = "",
    val language: Lang = Lang.HINGLISH,
    val model: String = "gemini-2.5-flash",
    val theme: String = "dark", // dark | light | system
    val ttsEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.1f,
    val historyEnabled: Boolean = true,
    val setupDone: Boolean = false,
    val hasKey: Boolean = false,
)

/** role is "user" or "model" (Gemini naming). */
data class ChatMsg(val role: String, val text: String, val time: Long = System.currentTimeMillis())

data class ConversationMeta(val id: String, val title: String, val updated: Long, val count: Int)

data class Conversation(
    val id: String,
    val title: String,
    val updated: Long,
    val messages: List<ChatMsg>,
) {
    fun toJson(): String {
        val arr = JSONArray()
        messages.forEach {
            arr.put(JSONObject().put("r", it.role).put("t", it.text).put("ts", it.time))
        }
        return JSONObject().put("id", id).put("title", title).put("updated", updated)
            .put("messages", arr).toString()
    }

    companion object {
        fun fromJson(s: String): Conversation {
            val j = JSONObject(s)
            val arr = j.getJSONArray("messages")
            val list = (0 until arr.length()).map {
                val m = arr.getJSONObject(it)
                ChatMsg(m.getString("r"), m.getString("t"), m.optLong("ts"))
            }
            return Conversation(j.getString("id"), j.getString("title"), j.getLong("updated"), list)
        }
    }
}
