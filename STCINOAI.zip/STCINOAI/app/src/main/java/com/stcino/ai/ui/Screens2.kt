@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.stcino.ai.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.stcino.ai.core.AppInfo
import com.stcino.ai.core.AppMatcher
import com.stcino.ai.core.CodeAssist
import com.stcino.ai.core.CodeMode
import com.stcino.ai.core.Command
import com.stcino.ai.core.CommandParser
import com.stcino.ai.core.YouTube
import com.stcino.ai.data.ConversationMeta
import java.text.DateFormat
import java.util.Date

// ============================ 6. App Launcher ============================
@Composable
fun LauncherScreen(vm: AppViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val container = (ctx.applicationContext as com.stcino.ai.StcinoApp).container
    var apps by remember { mutableStateOf<List<AppInfo>?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = container.apps.list() }
    Screen("Apps", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp)) {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search apps") })
            val list = apps
            if (list == null) {
                CircularProgressIndicator(Modifier.padding(24.dp))
            } else {
                val q = AppMatcher.norm(query)
                val shown = if (q.isEmpty()) list else list.filter { AppMatcher.norm(it.label).contains(q) }
                if (shown.isEmpty()) Text("Koi app nahi mila.", Modifier.padding(16.dp))
                LazyVerticalGrid(GridCells.Adaptive(84.dp), Modifier.fillMaxSize()) {
                    items(shown, key = { it.pkg }) { a ->
                        Column(
                            Modifier.clickable {
                                if (!container.apps.launch(a.pkg)) vm.notice("${a.label} nahi khul paya.")
                            }.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Image(a.icon, a.label, Modifier.size(48.dp))
                            Text(a.label, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

// ============================ 7. YouTube Music ============================
@Composable
fun MusicScreen(vm: AppViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    fun go(text: String) {
        val cmd = CommandParser.parse(text, s.assistantName)
        val query = if (cmd is Command.YouTube) cmd.query else text.trim()
        if (query.isEmpty()) { vm.notice("Song ya artist ka naam likhein."); return }
        if (!YouTube.open(ctx, query)) vm.notice("YouTube ya browser nahi khul paya.")
    }
    Screen("YouTube Music", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Song / artist (e.g. Play Arijit Singh songs)") })
            Button(onClick = { go(q) }, Modifier.fillMaxWidth()) { Text("Search on YouTube") }
            Text("Quick picks", style = MaterialTheme.typography.titleMedium)
            ChipRow(listOf("Arijit Singh songs", "lofi beats", "Hindi romantic songs", "workout music"), "", { it }) { go(it) }
            Text(
                "YouTube ka search page khulta hai (app ho to app me, warna browser me). Result aap khud chunte hain. Ads, premium aur background playback ke rules YouTube ke hi rehte hain.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ============================ 8. Coding Assistant ============================
@Composable
fun CodingScreen(vm: AppViewModel, nav: NavController) {
    val out by vm.codeOut.collectAsStateWithLifecycle()
    val busy by vm.codeBusy.collectAsStateWithLifecycle()
    val err by vm.codeErr.collectAsStateWithLifecycle()
    val export = rememberExporter()
    var mode by remember { mutableStateOf(CodeMode.GENERATE) }
    var lang by remember { mutableStateOf("Python") }
    var input by remember { mutableStateOf("") }
    Screen("Coding Assistant", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ChipRow(CodeMode.values().toList(), mode, { it.label }) { mode = it }
            ChipRow(CodeAssist.languages, lang, { it }) { lang = it }
            OutlinedTextField(
                input, { input = it }, Modifier.fillMaxWidth(), minLines = 4, maxLines = 12,
                label = { Text(if (mode == CodeMode.GENERATE || mode == CodeMode.STRUCTURE) "Kya banana hai?" else "Code / error / command paste karein") },
            )
            Button(onClick = { vm.askCode(mode, lang, input) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Working…" else mode.label)
            }
            if (busy) CircularProgressIndicator(Modifier.size(24.dp))
            err?.let { ErrorCard(it, { vm.askCode(mode, lang, input) }, { nav.navigate(Routes.Gemini) }) }
            if (out.isNotBlank()) RichText(out, export)
            Text(
                "Generated code kabhi apne aap run nahi hota. Terminal commands pehle explain hoti hain; chalane se pehle aap khud review karein.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ============================ 9. History ============================
@Composable
fun HistoryScreen(vm: AppViewModel, nav: NavController) {
    val list by vm.history.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    var renaming by remember { mutableStateOf<ConversationMeta?>(null) }
    var newTitle by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    LaunchedEffect(Unit) { vm.refreshHistory() }
    Screen("History", { nav.popBackStack() }, actions = {
        IconButton(onClick = { confirmClear = true }) { Icon(Icons.Default.Delete, "Clear all") }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Save conversation history")
                    Text("Band karne par nayi chat save nahi hogi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(s.historyEnabled, { on -> vm.save { it.copy(historyEnabled = on) } })
            }
            if (list.isEmpty()) Text("Abhi koi conversation nahi hai.", Modifier.padding(16.dp))
            LazyColumn {
                items(list, key = { it.id }) { m ->
                    ListItem(
                        headlineContent = { Text(m.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text(fmt.format(Date(m.updated)) + " · ${m.count} messages") },
                        modifier = Modifier.clickable { vm.openConversation(m.id); nav.navigate(Routes.Chat) },
                        trailingContent = {
                            Row {
                                IconButton(onClick = { renaming = m; newTitle = m.title }) { Icon(Icons.Default.Edit, "Rename") }
                                IconButton(onClick = { vm.deleteConversation(m.id) }) { Icon(Icons.Default.Delete, "Delete") }
                            }
                        },
                    )
                }
            }
        }
    }
    renaming?.let { m ->
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename") },
            text = { OutlinedTextField(newTitle, { newTitle = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.renameConversation(m.id, newTitle); renaming = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Saari history delete karein?") },
            text = { Text("Ye wapas nahi aayegi.") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Delete all") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}
