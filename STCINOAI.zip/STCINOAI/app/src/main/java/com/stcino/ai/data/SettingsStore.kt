package com.stcino.ai.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore by preferencesDataStore(name = "stcino_settings")

class SettingsStore(private val ctx: Context) {
    private object K {
        val name = stringPreferencesKey("name")
        val personality = stringPreferencesKey("personality")
        val custom = stringPreferencesKey("custom")
        val lang = stringPreferencesKey("lang")
        val model = stringPreferencesKey("model")
        val theme = stringPreferencesKey("theme")
        val tts = booleanPreferencesKey("tts")
        val rate = floatPreferencesKey("rate")
        val pitch = floatPreferencesKey("pitch")
        val history = booleanPreferencesKey("history")
        val setup = booleanPreferencesKey("setup")
        val keyEnc = stringPreferencesKey("key_enc")
    }

    private val d = Settings()

    val flow: Flow<Settings> = ctx.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            Settings(
                loaded = true,
                assistantName = p[K.name] ?: d.assistantName,
                personality = Personality.fromId(p[K.personality]),
                customPrompt = p[K.custom] ?: "",
                language = Lang.fromId(p[K.lang]),
                model = p[K.model] ?: d.model,
                theme = p[K.theme] ?: d.theme,
                ttsEnabled = p[K.tts] ?: d.ttsEnabled,
                speechRate = p[K.rate] ?: d.speechRate,
                pitch = p[K.pitch] ?: d.pitch,
                historyEnabled = p[K.history] ?: d.historyEnabled,
                setupDone = p[K.setup] ?: false,
                hasKey = p[K.keyEnc] != null,
            )
        }

    suspend fun save(s: Settings) {
        ctx.dataStore.edit {
            it[K.name] = s.assistantName
            it[K.personality] = s.personality.id
            it[K.custom] = s.customPrompt
            it[K.lang] = s.language.id
            it[K.model] = s.model
            it[K.theme] = s.theme
            it[K.tts] = s.ttsEnabled
            it[K.rate] = s.speechRate
            it[K.pitch] = s.pitch
            it[K.history] = s.historyEnabled
            it[K.setup] = s.setupDone
        }
    }

    suspend fun saveKey(raw: String) {
        val enc = SecureKey.encrypt(raw)
        ctx.dataStore.edit { it[K.keyEnc] = enc }
    }

    suspend fun readKey(): String? {
        val enc = ctx.dataStore.data.first()[K.keyEnc] ?: return null
        return SecureKey.decrypt(enc)
    }

    suspend fun clearKey() {
        ctx.dataStore.edit { it.remove(K.keyEnc) }
    }

    suspend fun resetAll() {
        ctx.dataStore.edit { it.clear() }
    }
}
