@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.stcino.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.stcino.ai.core.Shortcuts
import com.stcino.ai.core.Validators
import com.stcino.ai.data.Lang
import com.stcino.ai.data.Personality

// ============================ 10. Settings hub ============================
@Composable
fun SettingsScreen(nav: NavController) {
    Screen("Settings", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {
            listOf(
                "Customization" to Routes.Custom,
                "Gemini configuration" to Routes.Gemini,
                "Voice settings" to Routes.VoiceSet,
                "Permissions center" to Routes.Perms,
                "About & Privacy" to Routes.Privacy,
            ).forEach { (t, r) ->
                ListItem(headlineContent = { Text(t) }, modifier = Modifier.clickable { nav.navigate(r) })
            }
        }
    }
}

// ============================ Customization ============================
@Composable
fun CustomizationScreen(vm: AppViewModel, nav: NavController) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var name by remember(s.assistantName) { mutableStateOf(s.assistantName) }
    var custom by remember(s.customPrompt) { mutableStateOf(s.customPrompt) }
    Screen("Customization", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Assistant name")
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true)
            Text("Personality")
            ChipRow(Personality.values().toList(), s.personality, { it.label }) { p -> vm.save { it.copy(personality = p) } }
            if (s.personality == Personality.CUSTOM) {
                OutlinedTextField(custom, { custom = it }, Modifier.fillMaxWidth(), label = { Text("Custom personality") })
            }
            Text("Language")
            ChipRow(Lang.values().toList(), s.language, { it.label }) { l -> vm.save { it.copy(language = l) } }
            Text("Theme")
            ChipRow(listOf("dark", "light", "system"), s.theme, { it.replaceFirstChar { c -> c.uppercase() } }) { t -> vm.save { it.copy(theme = t) } }
            Button(onClick = {
                vm.save { it.copy(assistantName = Validators.assistantName(name), customPrompt = custom.trim().take(1000)) }
                vm.notice("Save ho gaya. App ke andar naam turant badal gaya.")
            }, Modifier.fillMaxWidth()) { Text("Save") }
            OutlinedButton(onClick = {
                val ok = Shortcuts.pinNamedShortcut(ctx, Validators.assistantName(name))
                if (!ok) vm.notice("Aapka launcher shortcut pinning support nahi karta.")
            }, Modifier.fillMaxWidth()) { Text("Home screen par is naam ka shortcut banayein") }
            Text(
                "Note: Android installed app ka launcher naam runtime me nahi badalne deta. App ke andar naam turant badalta hai; home screen ke liye upar wala shortcut custom naam ke saath banta hai.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ============================ Gemini configuration ============================
@Composable
fun GeminiScreen(vm: AppViewModel, nav: NavController) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val masked by vm.maskedKey.collectAsStateWithLifecycle()
    val conn by vm.conn.collectAsStateWithLifecycle()
    val models by vm.models.collectAsStateWithLifecycle()
    var key by remember { mutableStateOf("") }
    var model by remember(s.model) { mutableStateOf(s.model) }
    Screen("Gemini", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(if (masked.isNotEmpty()) "Saved key: $masked" else "Koi key save nahi hai.", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Gemini API key") },
                visualTransformation = PasswordVisualTransformation(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.saveKey(key); key = "" }, enabled = key.isNotBlank()) { Text("Save key") }
                OutlinedButton(onClick = { vm.deleteKey() }, enabled = masked.isNotEmpty()) { Text("Remove key") }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.testConnection() }, enabled = masked.isNotEmpty() && conn !is Conn.Testing) { Text("Test connection") }
                if (conn is Conn.Testing) CircularProgressIndicator(Modifier.size(22.dp))
            }
            val (dot, label) = when (val c = conn) {
                is Conn.Idle -> Color.Gray to "Not tested"
                is Conn.Testing -> Color(0xFFFFC107) to "Testing…"
                is Conn.Ok -> Color(0xFF4CAF50) to "Connected · ${c.count} models available"
                is Conn.Fail -> Color(0xFFF44336) to c.err.message
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
                Text(label)
            }
            (conn as? Conn.Fail)?.let { Button(onClick = { vm.testConnection() }) { Text("Retry") } }
            Text("Model", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Model id") })
            Button(onClick = { vm.setModel(model) }) { Text("Use this model") }
            if (models.isNotEmpty()) {
                Text("Aapki key ke liye available models (Test connection se aaye):", style = MaterialTheme.typography.bodySmall)
                ChipRow(models.take(30), s.model, { it }) { m -> model = m; vm.setModel(m) }
            }
            Text(
                "Security note: client-side API key ko phone par encrypt karke rakha jaata hai, par rooted device ya reverse-engineering se key nikal sakti hai. " +
                    "Public release ke liye apna backend proxy use karein jo key chhupaye aur usage limit lagaye. " +
                    "Free quota aur model access Google ki current terms aur aapke account par depend karte hain.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ============================ Voice settings ============================
@Composable
fun VoiceSettingsScreen(vm: AppViewModel, nav: NavController) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var rate by remember(s.speechRate) { mutableFloatStateOf(s.speechRate) }
    var pitch by remember(s.pitch) { mutableFloatStateOf(s.pitch) }
    Screen("Voice settings", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Jawab bolkar sunao", Modifier.weight(1f))
                Switch(s.ttsEnabled, { on -> vm.save { it.copy(ttsEnabled = on) } })
            }
            Text("Speaking speed: ${"%.2f".format(rate)}")
            Slider(rate, { rate = it }, valueRange = 0.5f..1.5f, onValueChangeFinished = { vm.save { it.copy(speechRate = rate) } })
            Text("Pitch: ${"%.2f".format(pitch)}")
            Slider(pitch, { pitch = it }, valueRange = 0.7f..1.5f, onValueChangeFinished = { vm.save { it.copy(pitch = pitch) } })
            Text("Recognition/speaking language")
            ChipRow(Lang.values().toList(), s.language, { it.label }) { l -> vm.save { it.copy(language = l) } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.speakTest() }) { Text("Test voice") }
                OutlinedButton(onClick = { vm.stopSpeaking() }) { Text("Stop") }
            }
            Text(
                "Awaaz ka gender/quality aapke phone ke installed Text-to-Speech engine par depend karta hai. Hindi voice ke liye Settings → System → Languages → Text-to-speech me Hindi voice data install karein.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ============================ Permissions center ============================
@Composable
fun PermissionsScreen(nav: NavController) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val mic = tick >= 0 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    Screen("Permissions center", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Microphone: " + if (mic) "Granted" else "Not granted", style = MaterialTheme.typography.titleMedium)
            Text("Sirf tab use hota hai jab aap mic button dabate hain. Voice ko text me badalne ke liye Android ki speech service use hoti hai (device ke hisaab se wo audio Google/online service ko bhej sakti hai).")
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            }) { Text("Open app permission settings") }
            Text("Internet: Gemini ko request bhejne ke liye (HTTPS).", style = MaterialTheme.typography.titleMedium)
            Text("Installed apps list: sirf launcher apps (QUERY_ALL_PACKAGES use nahi hota).", style = MaterialTheme.typography.titleMedium)
            Text("Accessibility / screen touch automation: is version me included nahi hai. Future me ye optional hoga, sirf aapke Android Settings me manually on karne par, disclosure ke saath; passwords/OTP kabhi collect nahi honge.")
        }
    }
}

// ============================ About & Privacy ============================
@Composable
fun PrivacyScreen(vm: AppViewModel, nav: NavController) {
    var confirm by remember { mutableStateOf(false) }
    Screen("About & Privacy", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("STCINO AI v1.0.0", style = MaterialTheme.typography.titleLarge)
            Text("• Aapke messages Google Gemini API ko HTTPS se bheje jaate hain jab aap chat/coding/voice use karte hain. Google ki policy un par lagu hoti hai.")
            Text("• App open karna, YouTube search aur history local hain; app apna koi server use nahi karta.")
            Text("• Conversation history sirf is phone me private storage me hai; aap rename/delete/band kar sakte hain.")
            Text("• API key Android Keystore se encrypt hokar rakhi jaati hai; kabhi log nahi hoti.")
            Text("• Assistant ek AI hai, insaan nahi. Gemini galat jawab de sakta hai; zaroori cheezein verify karein.")
            Text("• Permanent 'memory' nahi hai: sirf saved chats aur aapki settings use hoti hain.")
            Button(onClick = { vm.clearHistory() }, Modifier.fillMaxWidth()) { Text("Delete all conversations") }
            OutlinedButton(onClick = { vm.deleteKey() }, Modifier.fillMaxWidth()) { Text("Delete API key") }
            OutlinedButton(onClick = { confirm = true }, Modifier.fillMaxWidth()) { Text("Reset everything") }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Sab kuch reset karein?") },
            text = { Text("History, settings aur API key delete ho jayengi. Setup dobara hoga.") },
            confirmButton = { TextButton(onClick = { vm.resetAll(); confirm = false; nav.navigate(Routes.Splash) { popUpTo(0) } }) { Text("Reset") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}
