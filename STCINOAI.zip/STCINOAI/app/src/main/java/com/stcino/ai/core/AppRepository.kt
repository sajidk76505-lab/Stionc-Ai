package com.stcino.ai.core

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

/**
 * Lists apps that expose a LAUNCHER activity (needs the <queries> block in the manifest on
 * Android 11+) and launches them via getLaunchIntentForPackage. No hidden activities are started.
 */
class AppRepository(private val ctx: Context) {
    private var cache: List<AppInfo>? = null

    suspend fun list(force: Boolean = false): List<AppInfo> = withContext(Dispatchers.IO) {
        cache?.takeIf { !force }?.let { return@withContext it }
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = pm.queryIntentActivities(intent, 0)
            .mapNotNull { ri ->
                runCatching {
                    AppInfo(
                        ri.loadLabel(pm).toString(),
                        ri.activityInfo.packageName,
                        ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
                    )
                }.getOrNull()
            }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        cache = out
        out
    }

    fun launch(pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}
