package com.stcino.ai.ai

import com.stcino.ai.data.ChatMsg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * Gemini REST client (Generative Language API, v1beta) over HTTPS.
 * The key is sent in the `x-goog-api-key` header (never in the URL) and never logged.
 */
class GeminiProvider(private val keyProvider: suspend () -> String?) : AiProvider {
    private val base = "https://generativelanguage.googleapis.com/v1beta"
    private val modelRegex = Regex("^[A-Za-z0-9._-]{3,80}$")

    override suspend fun generate(system: String, history: List<ChatMsg>, model: String): AiResult<String> {
        val m = model.trim().removePrefix("models/")
        if (!modelRegex.matches(m)) return AiResult.Err(ErrKind.BAD_RESPONSE, "Model ka naam sahi nahi hai.")
        val contents = JSONArray()
        history.dropWhile { it.role != "user" }.forEach {
            contents.put(
                JSONObject().put("role", it.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        if (contents.length() == 0) return AiResult.Err(ErrKind.BAD_RESPONSE, "Bhejne ke liye kuch nahi hai.")
        val body = JSONObject().put("contents", contents)
        if (system.isNotBlank()) {
            body.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
        }
        return when (val r = request("POST", "$base/models/$m:generateContent", body.toString())) {
            is AiResult.Ok -> GeminiParser.parseText(r.value)
            is AiResult.Err -> r
        }
    }

    override suspend fun listModels(): AiResult<List<String>> =
        when (val r = request("GET", "$base/models?pageSize=100", null)) {
            is AiResult.Ok -> GeminiParser.parseModels(r.value)
            is AiResult.Err -> r
        }

    private suspend fun request(method: String, url: String, body: String?): AiResult<String> {
        val key = keyProvider()
        if (key.isNullOrBlank()) {
            return AiResult.Err(ErrKind.NO_KEY, "Pehle Settings → Gemini me API key save karein.")
        }
        return withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                conn = c
                c.requestMethod = method
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                c.setRequestProperty("x-goog-api-key", key)
                c.setRequestProperty("Content-Type", "application/json")
                if (body != null) {
                    c.doOutput = true
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code in 200..299) AiResult.Ok(text) else GeminiParser.httpError(code, text)
            } catch (e: SocketTimeoutException) {
                AiResult.Err(ErrKind.TIMEOUT, "Request time out ho gayi. Internet check karke Retry karein.")
            } catch (e: UnknownHostException) {
                AiResult.Err(ErrKind.NETWORK, "Internet connection nahi hai.")
            } catch (e: IOException) {
                AiResult.Err(ErrKind.NETWORK, "Network error aaya. Retry karein.")
            } finally {
                conn?.disconnect()
            }
        }
    }
}
