package com.stcino.ai.core

object Validators {
    const val DEFAULT_NAME = "STCINO AI"

    fun assistantName(raw: String): String {
        val c = raw.filter { it.isLetterOrDigit() || it == ' ' || it == '-' || it == '.' }.trim().take(24)
        return c.ifBlank { DEFAULT_NAME }
    }

    fun userText(raw: String): String? = raw.trim().take(4000).ifEmpty { null }

    fun apiKey(raw: String): String? {
        val k = raw.trim()
        return if (Regex("^[A-Za-z0-9_-]{20,100}$").matches(k)) k else null
    }

    fun mask(key: String): String =
        if (key.length <= 8) "••••" else key.take(4) + "••••••••" + key.takeLast(4)

    fun model(raw: String): String? {
        val m = raw.trim().removePrefix("models/")
        return if (Regex("^[A-Za-z0-9._-]{3,80}$").matches(m)) m else null
    }
}
