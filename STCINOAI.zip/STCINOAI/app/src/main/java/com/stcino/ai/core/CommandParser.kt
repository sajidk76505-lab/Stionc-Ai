package com.stcino.ai.core

import com.stcino.ai.data.Lang

sealed class Command {
    data class OpenApp(val name: String) : Command()
    data class YouTube(val query: String) : Command()
    data class SetLanguage(val lang: Lang) : Command()
    data class Chat(val text: String) : Command()
}

/**
 * Small rule-based parser for English / Hinglish / Hindi (Devanagari) commands.
 * Anything not recognised goes to Gemini as normal chat.
 */
object CommandParser {
    private const val OPEN_WORDS = "open|launch|start|ओपन"
    private const val OPEN_POST =
        "open\\s+kar(?:o|do)|open\\s+kar\\s+do|kholo|khol\\s+do|khol|chalu\\s+kar(?:o|do)|खोलो|खोल\\s+दो|खोलिए|ओपन\\s+करो|ओपन\\s+कर\\s+दो"
    private const val YT_VERBS = "search|play|chalao|bajao|sunao|dikhao|सर्च|चलाओ|बजाओ|सुनाओ"
    private const val ON_HI = "pe|par|per|me|mein|पर|में"

    private val openPre = Regex("^(?:please\\s+)?(?:$OPEN_WORDS)\\s+(.+)$")
    private val openPost = Regex("^(?:please\\s+)?(.+?)\\s+(?:$OPEN_POST)$")
    private val ytOn = Regex("^(?:play|search|find)\\s+(.+?)\\s+(?:on|in)\\s+(?:youtube|यूट्यूब)$")
    private val ytHi = Regex("^(?:youtube|यूट्यूब)\\s+(?:$ON_HI)\\s+(.+?)(?:\\s+(?:$YT_VERBS)(?:\\s+kar(?:o|do)|\\s+करो)?)?$")
    private val ytHi2 = Regex("^(.+?)\\s+(?:youtube|यूट्यूब)\\s+(?:$ON_HI)\\s+(?:$YT_VERBS)(?:\\s+kar(?:o|do)|\\s+करो)?$")
    private val ytBare = Regex("^(?:play|search)\\s+(.+)$")

    fun stripWakeWord(text: String, name: String): String {
        val t = text.trim()
        val candidates = listOf(name.trim(), name.trim().split(' ').first()).filter { it.isNotEmpty() }.distinct()
        for (c in candidates) {
            val re = Regex("^(?:(?:hey|hi|hello|ok|okay)\\s+)?${Regex.escape(c)}\\s*[,:!.-]*\\s*", RegexOption.IGNORE_CASE)
            val out = re.replaceFirst(t, "").trim()
            if (out != t) return out
        }
        return t
    }

    fun parse(raw: String, assistantName: String): Command {
        val original = raw.trim()
        val stripped = stripWakeWord(original, assistantName).ifBlank { original }
        val t = stripped.lowercase().trim().trimEnd('.', '!', '?', ',', '।').trim()
        val words = t.split(Regex("\\s+")).size

        if (words <= 7 && Regex("jawab|reply|baat|answer|bolo|जवाब").containsMatchIn(t)) {
            if (Regex("hindi (mein|me)|in hindi|हिंदी में|हिन्दी में").containsMatchIn(t)) return Command.SetLanguage(Lang.HINDI)
            if (Regex("english (mein|me)|in english|इंग्लिश में").containsMatchIn(t)) return Command.SetLanguage(Lang.ENGLISH)
            if (Regex("hinglish (mein|me)|in hinglish").containsMatchIn(t)) return Command.SetLanguage(Lang.HINGLISH)
        }

        ytOn.find(t)?.let { return Command.YouTube(it.groupValues[1].trim().take(200)) }
        ytHi.find(t)?.let { return Command.YouTube(it.groupValues[1].trim().take(200)) }
        ytHi2.find(t)?.let { return Command.YouTube(it.groupValues[1].trim().take(200)) }

        if (words <= 5) {
            openPre.find(t)?.let { return Command.OpenApp(it.groupValues[1].trim()) }
            openPost.find(t)?.let { return Command.OpenApp(it.groupValues[1].trim()) }
        }
        // "play X" / "search X" are treated as YouTube searches (documented behaviour).
        if (words <= 10) ytBare.find(t)?.let { return Command.YouTube(it.groupValues[1].trim().take(200)) }

        return Command.Chat(stripped)
    }
}
