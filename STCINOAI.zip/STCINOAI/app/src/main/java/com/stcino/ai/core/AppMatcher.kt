package com.stcino.ai.core

sealed class Match<out T> {
    object None : Match<Nothing>()
    data class One<T>(val item: T) : Match<T>()
    data class Many<T>(val items: List<T>) : Match<T>()
}

/** Fuzzy-but-safe matching of a spoken app name to installed app labels. */
object AppMatcher {
    private val aliases = mapOf(
        "yt" to "youtube", "यूट्यूब" to "youtube", "यू ट्यूब" to "youtube",
        "क्रोम" to "chrome", "chrome browser" to "chrome", "google chrome" to "chrome",
        "setting" to "settings", "सेटिंग" to "settings", "सेटिंग्स" to "settings",
        "calc" to "calculator", "कैलकुलेटर" to "calculator",
        "कैमरा" to "camera", "गैलरी" to "gallery",
        "व्हाट्सएप" to "whatsapp", "insta" to "instagram",
    )

    fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()

    fun canonical(query: String): String {
        val q = norm(query).removePrefix("the ").removeSuffix(" app").trim()
        return aliases[q] ?: q
    }

    fun <T> match(query: String, items: List<T>, label: (T) -> String): Match<T> {
        val q = canonical(query)
        if (q.isEmpty()) return Match.None
        val exact = items.filter { norm(label(it)) == q }
        if (exact.size == 1) return Match.One(exact[0])
        if (exact.size > 1) return Match.Many(exact.take(5))
        val tokens = q.split(' ')
        val loose = items.filter {
            val l = norm(label(it))
            l.startsWith(q) || l.contains(q) || tokens.all { t -> l.contains(t) }
        }
        return when (loose.size) {
            0 -> Match.None
            1 -> Match.One(loose[0])
            else -> {
                val starts = loose.filter { norm(label(it)).startsWith(q) }
                if (starts.size == 1) Match.One(starts[0]) else Match.Many(loose.take(5))
            }
        }
    }
}
