package com.stcino.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stcino.ai.ui.AppNav
import com.stcino.ai.ui.AppViewModel
import com.stcino.ai.ui.StcinoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppViewModel = viewModel()
            val s by vm.settings.collectAsStateWithLifecycle()
            StcinoTheme(s.theme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { AppNav(vm) }
            }
        }
    }
}
