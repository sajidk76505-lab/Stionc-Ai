package com.stcino.ai.ui

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

object Routes {
    const val Splash = "splash"
    const val Setup = "setup"
    const val Home = "home"
    const val Voice = "voice"
    const val Chat = "chat"
    const val Launcher = "launcher"
    const val Music = "music"
    const val Coding = "coding"
    const val History = "history"
    const val Settings = "settings"
    const val Custom = "custom"
    const val Gemini = "gemini"
    const val VoiceSet = "voiceset"
    const val Perms = "perms"
    const val Privacy = "privacy"
}

@Composable
fun AppNav(vm: AppViewModel) {
    val nav = rememberNavController()
    val ctx = LocalContext.current
    val notice by vm.notice.collectAsStateWithLifecycle()
    LaunchedEffect(notice) {
        notice?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
            vm.clearNotice()
        }
    }
    NavHost(nav, startDestination = Routes.Splash) {
        composable(Routes.Splash) {
            SplashScreen(vm) { done ->
                nav.navigate(if (done) Routes.Home else Routes.Setup) { popUpTo(Routes.Splash) { inclusive = true } }
            }
        }
        composable(Routes.Setup) {
            SetupScreen(vm) { nav.navigate(Routes.Home) { popUpTo(Routes.Setup) { inclusive = true } } }
        }
        composable(Routes.Home) { HomeScreen(vm, nav) }
        composable(Routes.Voice) { VoiceScreen(vm, nav) }
        composable(Routes.Chat) { ChatScreen(vm, nav) }
        composable(Routes.Launcher) { LauncherScreen(vm, nav) }
        composable(Routes.Music) { MusicScreen(vm, nav) }
        composable(Routes.Coding) { CodingScreen(vm, nav) }
        composable(Routes.History) { HistoryScreen(vm, nav) }
        composable(Routes.Settings) { SettingsScreen(nav) }
        composable(Routes.Custom) { CustomizationScreen(vm, nav) }
        composable(Routes.Gemini) { GeminiScreen(vm, nav) }
        composable(Routes.VoiceSet) { VoiceSettingsScreen(vm, nav) }
        composable(Routes.Perms) { PermissionsScreen(nav) }
        composable(Routes.Privacy) { PrivacyScreen(vm, nav) }
    }
}
