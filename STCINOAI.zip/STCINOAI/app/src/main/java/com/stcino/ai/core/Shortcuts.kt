package com.stcino.ai.core

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.stcino.ai.MainActivity
import com.stcino.ai.R

/**
 * Android cannot rename an installed app's launcher label at runtime. The supported workaround:
 * pin a home-screen shortcut that carries the user's custom name and opens this app.
 */
object Shortcuts {
    fun pinNamedShortcut(ctx: Context, name: String): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) return false
        val info = ShortcutInfoCompat.Builder(ctx, "stcino_custom_name")
            .setShortLabel(name)
            .setLongLabel(name)
            .setIcon(IconCompat.createWithResource(ctx, R.mipmap.ic_launcher))
            .setIntent(Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
            .build()
        return ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
    }
}
