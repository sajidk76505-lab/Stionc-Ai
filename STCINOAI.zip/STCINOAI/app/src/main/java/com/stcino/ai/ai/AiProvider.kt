package com.stcino.ai.ai

import com.stcino.ai.data.ChatMsg
import org.json.JSONException
import org.json.JSONObject

enum class ErrKind { NO_KEY, INVALID_KEY, RATE_LIMIT, NETWORK, TIMEOUT, SERVER, BAD_RESPONSE }

sealed class AiResult<out T> {
    data class Ok<T>(val value: T) : AiResult<T>()
    data class Err(val kind: ErrKind, val message: String) : AiResult<Nothing>()
}

/** Provider-agnostic interface. Add OpenAI/Ollama/etc. later by implementing this. */
interface AiProvider {
    suspend fun generate(system: String, history: List<ChatMsg>, model: String): AiResult<String>
    suspend fun listModels(): AiResult<List<String>>
}

/** Pure parsing helpers (unit-testable, no Android dependencies). */
object GeminiParser {
    fun parseText(body: String): AiResult<String> = try {
        val j = JSONObject(body)
        val cands = j.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = j.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            AiResult.Err(
                ErrKind.BAD_RESPONSE,
                if (block.isNotBlank()) "Safety filter ne request block ki ($block)." else "Gemini ne khali jawab diya."
            )
        } else {
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            if (sb.isBlank()) AiResult.Err(ErrKind.BAD_RESPONSE, "Gemini ne khali jawab diya.")
            else AiResult.Ok(sb.toString())
        }
    } catch (e: JSONException) {
        AiResult.Err(ErrKind.BAD_RESPONSE, "Gemini ka response samajh nahi aaya.")
    }

    fun parseModels(body: String): AiResult<List<String>> = try {
        val arr = JSONObject(body).optJSONArray("models")
        val out = mutableListOf<String>()
        if (arr != null) for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val methods = m.optJSONArray("supportedGenerationMethods")
            var ok = false
            if (methods != null) for (k in 0 until methods.length()) if (methods.getString(k) == "generateContent") ok = true
            if (ok) out.add(m.getString("name").removePrefix("models/"))
        }
        AiResult.Ok(out)
    } catch (e: JSONException) {
        AiResult.Err(ErrKind.BAD_RESPONSE, "Model list samajh nahi aayi.")
    }

    private fun errorMessage(body: String): String? = try {
        JSONObject(body).optJSONObject("error")?.optString("message")?.take(200)
    } catch (e: JSONException) {
        null
    }

    /** Maps an HTTP failure to a friendly error. Never includes the API key. */
    fun httpError(code: Int, body: String): AiResult.Err = when {
        code == 429 -> AiResult.Err(ErrKind.RATE_LIMIT, "Quota ya rate limit poori ho gayi. Thodi der baad Retry karein.")
        code == 401 || code == 403 || (code == 400 && (body.contains("API_KEY_INVALID") || body.contains("API key not valid"))) ->
            AiResult.Err(ErrKind.INVALID_KEY, "API key galat hai ya is key ko access nahi hai. Settings → Gemini me check karein.")
        code == 404 -> AiResult.Err(ErrKind.BAD_RESPONSE, "Ye model nahi mila. Settings me dusra model chunein.")
        code >= 500 -> AiResult.Err(ErrKind.SERVER, "Gemini server abhi busy hai. Retry karein.")
        else -> AiResult.Err(ErrKind.BAD_RESPONSE, "Request fail hui ($code). " + (errorMessage(body) ?: ""))
    }
}
