package com.stcino.ai.core

enum class CodeMode(val label: String, val instruction: String) {
    GENERATE("Generate", "Write complete, working, well-commented code for the request."),
    EXPLAIN("Explain", "Explain what this code does, step by step, in simple words."),
    DEBUG("Debug", "Find the cause of this error/bug, explain it, and give the corrected code."),
    REFACTOR("Refactor", "Refactor this code for readability and best practices; list what changed."),
    STRUCTURE("Project structure", "Propose a clean project directory structure with a short purpose for each file, then key starter files."),
    FORMAT("Format", "Reformat this code with standard style conventions without changing behaviour."),
    COMMAND("Explain command", "Explain what this terminal command does, each flag, and any risks BEFORE it is run. Do not suggest running it blindly; flag destructive effects clearly.");
}

object CodeAssist {
    val languages = listOf(
        "Python", "JavaScript", "TypeScript", "HTML", "CSS", "Java", "Kotlin",
        "SQL", "React Native", "Node.js", "Android"
    )

    fun system(mode: CodeMode, lang: String): String =
        "You are a senior software engineer helping on $lang. ${mode.instruction} " +
            "Use Markdown code fences with language tags. Be concise outside code. " +
            "You cannot execute code; never claim you ran anything. " +
            "Warn clearly about destructive shell commands (rm -rf, dd, mkfs, sudo, curl|sh)."
}
