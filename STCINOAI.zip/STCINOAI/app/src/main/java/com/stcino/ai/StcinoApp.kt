package com.stcino.ai

import android.app.Application
import android.content.Context
import com.stcino.ai.ai.AiProvider
import com.stcino.ai.ai.GeminiProvider
import com.stcino.ai.core.AppRepository
import com.stcino.ai.data.HistoryRepository
import com.stcino.ai.data.SettingsStore
import com.stcino.ai.voice.SpeechController
import com.stcino.ai.voice.TtsController

/** Manual dependency container (no DI framework → no kapt/KSP → lighter builds). */
class AppContainer(ctx: Context) {
    val settings = SettingsStore(ctx)
    val history = HistoryRepository(ctx)
    val ai: AiProvider = GeminiProvider { settings.readKey() }
    val apps = AppRepository(ctx)
    val tts by lazy { TtsController(ctx) }
    val speech by lazy { SpeechController(ctx) }
}

class StcinoApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
