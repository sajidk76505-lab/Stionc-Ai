package com.stcino.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.stcino.ai.core.TextTools
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsController(ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { _speaking.value = true }
                    override fun onDone(utteranceId: String?) { _speaking.value = false }
                    @Suppress("OVERRIDE_DEPRECATION")
                    override fun onError(utteranceId: String?) { _speaking.value = false }
                })
            }
        }
    }

    fun speak(text: String, langTag: String, rate: Float, pitch: Float) {
        val t = tts ?: return
        if (!ready) return
        val clean = TextTools.forSpeech(text)
        if (clean.isBlank()) return
        val loc = Locale.forLanguageTag(langTag)
        t.language = loc
        // Voice gender is not exposed by Android; prefer a voice whose name says "female" if present.
        runCatching {
            t.voices?.firstOrNull {
                it.locale.language == loc.language && !it.isNetworkConnectionRequired &&
                    it.name.contains("female", ignoreCase = true)
            }?.let { t.voice = it }
        }
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        t.speak(clean.take(3000), TextToSpeech.QUEUE_FLUSH, null, "stcino-" + System.nanoTime())
    }

    fun stop() {
        tts?.stop()
        _speaking.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
