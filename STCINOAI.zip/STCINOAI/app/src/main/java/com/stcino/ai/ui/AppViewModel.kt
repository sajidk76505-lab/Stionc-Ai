package com.stcino.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.stcino.ai.StcinoApp
import com.stcino.ai.ai.AiResult
import com.stcino.ai.core.AppInfo
import com.stcino.ai.core.AppMatcher
import com.stcino.ai.core.CodeAssist
import com.stcino.ai.core.CodeMode
import com.stcino.ai.core.Command
import com.stcino.ai.core.CommandParser
import com.stcino.ai.core.Match
import com.stcino.ai.core.PromptBuilder
import com.stcino.ai.core.Validators
import com.stcino.ai.core.YouTube
import com.stcino.ai.data.ChatMsg
import com.stcino.ai.data.Conversation
import com.stcino.ai.data.ConversationMeta
import com.stcino.ai.data.Lang
import com.stcino.ai.data.Personality
import com.stcino.ai.data.Settings
import com.stcino.ai.voice.SpeechState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

sealed class Conn {
    object Idle : Conn()
    object Testing : Conn()
    data class Ok(val count: Int) : Conn()
    data class Fail(val err: AiResult.Err) : Conn()
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as StcinoApp).container

    val settings: StateFlow<Settings> =
        c.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())

    // ---- chat state ----
    private val _messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val messages = _messages.asStateFlow()
    private val _choices = MutableStateFlow<List<AppInfo>>(emptyList())
    val choices = _choices.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()
    private val _error = MutableStateFlow<AiResult.Err?>(null)
    val error = _error.asStateFlow()
    private val _notice = MutableStateFlow<String?>(null)
    val notice = _notice.asStateFlow()
    private val _history = MutableStateFlow<List<ConversationMeta>>(emptyList())
    val history = _history.asStateFlow()

    val speechState = c.speech.state
    val speaking = c.tts.speaking

    private var convId: String? = null
    private var convTitle: String? = null
    private val persistLock = Mutex()

    // ---- gemini config state ----
    private val _masked = MutableStateFlow("")
    val maskedKey = _masked.asStateFlow()
    private val _conn = MutableStateFlow<Conn>(Conn.Idle)
    val conn = _conn.asStateFlow()
    private val _models = MutableStateFlow<List<String>>(emptyList())
    val models = _models.asStateFlow()

    // ---- coding assistant state ----
    private val _codeOut = MutableStateFlow("")
    val codeOut = _codeOut.asStateFlow()
    private val _codeBusy = MutableStateFlow(false)
    val codeBusy = _codeBusy.asStateFlow()
    private val _codeErr = MutableStateFlow<AiResult.Err?>(null)
    val codeErr = _codeErr.asStateFlow()

    init {
        refreshHistory()
        refreshKeyMask()
        viewModelScope.launch {
            c.speech.state.collect {
                if (it is SpeechState.Error) {
                    _notice.value = it.message
                    c.speech.reset()
                }
            }
        }
    }

    fun clearNotice() { _notice.value = null }
    fun notice(msg: String) { _notice.value = msg }

    // ===================== settings =====================
    fun save(transform: (Settings) -> Settings) {
        viewModelScope.launch { c.settings.save(transform(settings.value)) }
    }

    fun completeSetup(name: String, p: Personality, custom: String, lang: Lang, tts: Boolean, key: String) {
        viewModelScope.launch {
            c.settings.save(
                settings.value.copy(
                    assistantName = Validators.assistantName(name), personality = p,
                    customPrompt = custom.trim().take(1000), language = lang,
                    ttsEnabled = tts, setupDone = true
                )
            )
            Validators.apiKey(key)?.let { c.settings.saveKey(it); refreshKeyMask() }
        }
    }

    // ===================== chat =====================
    private fun say(s: Settings, hinglish: String, english: String) =
        if (s.language == Lang.ENGLISH) english else hinglish

    private fun addMsg(m: ChatMsg) {
        _messages.value = _messages.value + m
        persist()
    }

    private fun reply(text: String) {
        addMsg(ChatMsg("model", text))
        val s = settings.value
        if (s.ttsEnabled) c.tts.speak(text, s.language.speechTag, s.speechRate, s.pitch)
    }

    private fun persist() {
        if (!settings.value.historyEnabled) return
        val id = convId ?: UUID.randomUUID().toString().also { convId = it }
        viewModelScope.launch {
            persistLock.withLock {
                c.history.save(Conversation(id, convTitle ?: "New chat", System.currentTimeMillis(), _messages.value))
            }
            refreshHistory()
        }
    }

    fun send(raw: String) {
        val text = Validators.userText(raw) ?: return
        if (_busy.value) return
        c.tts.stop()
        _choices.value = emptyList()
        _error.value = null
        val s = settings.value
        if (convTitle == null) convTitle = text.take(40)
        addMsg(ChatMsg("user", text))
        when (val cmd = CommandParser.parse(text, s.assistantName)) {
            is Command.OpenApp -> openApp(cmd.name, s)
            is Command.YouTube -> {
                val ok = YouTube.open(getApplication(), cmd.query)
                reply(
                    if (ok) say(s, "YouTube par '${cmd.query}' search khol rahi hoon. Result aap khud chun sakte hain.",
                        "Opening YouTube search for '${cmd.query}'. You can pick the result yourself.")
                    else say(s, "YouTube ya browser nahi khul paya.", "I couldn't open YouTube or a browser.")
                )
            }
            is Command.SetLanguage -> {
                save { it.copy(language = cmd.lang) }
                reply(
                    when (cmd.lang) {
                        Lang.HINDI -> "ठीक है, अब मैं हिंदी में जवाब दूँगी।"
                        Lang.ENGLISH -> "Sure, I'll reply in English from now on."
                        Lang.HINGLISH -> "Theek hai, ab main Hinglish me jawab dungi."
                    }
                )
            }
            is Command.Chat -> askAi()
        }
    }

    private fun openApp(name: String, s: Settings) {
        viewModelScope.launch {
            val apps = c.apps.list()
            when (val m = AppMatcher.match(name, apps) { it.label }) {
                is Match.One -> launchApp(m.item, s)
                is Match.Many -> {
                    _choices.value = m.items
                    reply(say(s, "Kaunsa kholna hai? Neeche se chunein.", "Which one should I open? Pick below."))
                }
                Match.None -> reply(
                    say(s, "'$name' naam ka app nahi mila. App Launcher me search karke dekhein.",
                        "I couldn't find an app called '$name'. Try the App Launcher.")
                )
            }
        }
    }

    private fun launchApp(app: AppInfo, s: Settings) {
        if (c.apps.launch(app.pkg)) reply(say(s, "${app.label} khol rahi hoon.", "Opening ${app.label}."))
        else reply(say(s, "${app.label} nahi khul paya.", "I couldn't open ${app.label}."))
    }

    fun launchChoice(app: AppInfo) {
        _choices.value = emptyList()
        launchApp(app, settings.value)
    }

    private fun askAi() {
        val s = settings.value
        _busy.value = true
        _error.value = null
        viewModelScope.launch {
            val r = c.ai.generate(PromptBuilder.system(s), _messages.value.takeLast(20), s.model)
            _busy.value = false
            when (r) {
                is AiResult.Ok -> reply(r.value)
                is AiResult.Err -> _error.value = r
            }
        }
    }

    fun retry() { if (!_busy.value && _error.value != null) askAi() }

    fun newChat() {
        c.tts.stop()
        convId = null; convTitle = null
        _messages.value = emptyList(); _choices.value = emptyList(); _error.value = null
    }

    // ===================== voice =====================
    fun startListening() {
        c.tts.stop()
        c.speech.start(settings.value.language.speechTag) { send(it) }
    }
    fun finishListening() = c.speech.finish()
    fun cancelListening() = c.speech.cancel()
    fun stopSpeaking() = c.tts.stop()
    fun speakTest() {
        val s = settings.value
        c.tts.speak(say(s, "Namaste! Main ${s.assistantName} hoon. Aapki awaaz test ho rahi hai.",
            "Hello! I'm ${s.assistantName}. This is a voice test."), s.language.speechTag, s.speechRate, s.pitch)
    }

    // ===================== history =====================
    fun refreshHistory() { viewModelScope.launch { _history.value = c.history.list() } }

    fun openConversation(id: String) {
        viewModelScope.launch {
            c.history.load(id)?.let {
                c.tts.stop()
                convId = it.id; convTitle = it.title
                _messages.value = it.messages; _choices.value = emptyList(); _error.value = null
            }
        }
    }
    fun renameConversation(id: String, title: String) {
        val t = title.trim().take(60).ifEmpty { return }
        viewModelScope.launch {
            c.history.rename(id, t)
            if (id == convId) convTitle = t
            refreshHistory()
        }
    }
    fun deleteConversation(id: String) {
        viewModelScope.launch {
            c.history.delete(id)
            if (id == convId) newChat()
            refreshHistory()
        }
    }
    fun clearHistory() {
        viewModelScope.launch { c.history.clearAll(); newChat(); refreshHistory() }
    }

    // ===================== gemini config =====================
    private fun refreshKeyMask() {
        viewModelScope.launch { _masked.value = c.settings.readKey()?.let(Validators::mask).orEmpty() }
    }

    fun saveKey(raw: String) {
        val k = Validators.apiKey(raw)
        if (k == null) { _notice.value = "API key ka format sahi nahi lag raha."; return }
        viewModelScope.launch {
            c.settings.saveKey(k)
            refreshKeyMask()
            _conn.value = Conn.Idle
            _notice.value = "Key secure storage me save ho gayi."
        }
    }

    fun deleteKey() {
        viewModelScope.launch {
            c.settings.clearKey()
            _masked.value = ""; _conn.value = Conn.Idle; _models.value = emptyList()
            _notice.value = "API key hata di gayi."
        }
    }

    fun testConnection() {
        _conn.value = Conn.Testing
        viewModelScope.launch {
            when (val r = c.ai.listModels()) {
                is AiResult.Ok -> { _models.value = r.value; _conn.value = Conn.Ok(r.value.size) }
                is AiResult.Err -> _conn.value = Conn.Fail(r)
            }
        }
    }

    fun setModel(raw: String) {
        val m = Validators.model(raw)
        if (m == null) { _notice.value = "Model ka naam sahi nahi hai."; return }
        save { it.copy(model = m) }
    }

    // ===================== coding assistant =====================
    fun askCode(mode: CodeMode, lang: String, input: String) {
        val t = Validators.userText(input)
        if (t == null) { _notice.value = "Pehle kuch likhein."; return }
        if (_codeBusy.value) return
        _codeBusy.value = true
        _codeErr.value = null
        viewModelScope.launch {
            val r = c.ai.generate(CodeAssist.system(mode, lang), listOf(ChatMsg("user", t)), settings.value.model)
            _codeBusy.value = false
            when (r) {
                is AiResult.Ok -> _codeOut.value = r.value
                is AiResult.Err -> _codeErr.value = r
            }
        }
    }

    // ===================== privacy =====================
    fun resetAll() {
        viewModelScope.launch {
            c.history.clearAll()
            c.settings.clearKey()
            c.settings.resetAll()
            newChat(); refreshHistory(); refreshKeyMask()
            _codeOut.value = ""; _models.value = emptyList(); _conn.value = Conn.Idle
            _notice.value = "Saara local data delete ho gaya."
        }
    }

    override fun onCleared() {
        c.speech.cancel()
        c.tts.stop()
    }
}
