package com.stcino.ai.core

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder

/**
 * Opens a YouTube *search results page* via a standard HTTPS URL. The official YouTube app is
 * preferred when installed; otherwise any browser handles the same URL. The user picks the
 * result themselves. Nothing here bypasses ads, premium or copyright rules.
 */
object YouTube {
    fun searchUrl(query: String): String =
        "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query.trim(), "UTF-8")

    fun open(ctx: Context, query: String): Boolean {
        val q = query.trim().take(200)
        if (q.isEmpty()) return false
        val uri = Uri.parse(searchUrl(q))
        val viaApp = Intent(Intent.ACTION_VIEW, uri)
            .setPackage("com.google.android.youtube")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(viaApp)
            true
        } catch (e: ActivityNotFoundException) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                true
            } catch (e2: ActivityNotFoundException) {
                false
            }
        }
    }
}
