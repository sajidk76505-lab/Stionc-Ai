@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.stcino.ai.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.stcino.ai.ai.ErrKind
import com.stcino.ai.data.Lang
import com.stcino.ai.data.Personality
import com.stcino.ai.voice.SpeechState
import kotlinx.coroutines.delay

// ============================ 1. Splash ============================
@Composable
fun SplashScreen(vm: AppViewModel, onDone: (Boolean) -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    LaunchedEffect(s.loaded) {
        if (s.loaded) { delay(900); onDone(s.setupDone) }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AiOrb(true, Modifier.size(160.dp))
            Spacer(Modifier.height(16.dp))
            Text(s.assistantName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

// ============================ 2. Setup ============================
@Composable
fun SetupScreen(vm: AppViewModel, onDone: () -> Unit) {
    var name by remember { mutableStateOf("STCINO AI") }
    var p by remember { mutableStateOf(Personality.FRIENDLY) }
    var custom by remember { mutableStateOf("") }
    var lang by remember { mutableStateOf(Lang.HINGLISH) }
    var tts by remember { mutableStateOf(true) }
    var key by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { AiOrb(false, Modifier.size(110.dp)) }
        Text("Setup", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Assistant ka naam (Jarvis AI, Maria AI, My Personal AI…)")
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Assistant name") })
        Text("Personality")
        ChipRow(Personality.values().toList(), p, { it.label }) { p = it }
        if (p == Personality.CUSTOM) {
            OutlinedTextField(custom, { custom = it }, Modifier.fillMaxWidth(), label = { Text("Describe the personality") })
        }
        Text("Language")
        ChipRow(Lang.values().toList(), lang, { it.label }) { lang = it }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Jawab bolkar sunao (voice output)", Modifier.weight(1f))
            Switch(tts, { tts = it })
        }
        Text("Gemini API key (optional, baad me Settings me bhi de sakte hain)")
        OutlinedTextField(
            key, { key = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("API key") },
            visualTransformation = PasswordVisualTransformation(),
        )
        Text(
            "Key aapke phone me Android Keystore se encrypt hokar save hoti hai. Free quota Google ki policy par depend karta hai.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(onClick = { vm.completeSetup(name, p, custom, lang, tts, key); onDone() }, Modifier.fillMaxWidth()) {
            Text("Finish setup")
        }
    }
}

// ============================ 3. Home ============================
@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val speech by vm.speechState.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listening = speech is SpeechState.Listening
    val status = when {
        !s.hasKey -> "Gemini key set nahi hai (Settings → Gemini)"
        busy -> "Soch rahi hoon…"
        speaking -> "Bol rahi hoon…"
        listening -> "Sun rahi hoon…"
        else -> "Ready"
    }
    LaunchedEffect(Unit) { vm.refreshHistory() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.assistantName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = { nav.navigate(Routes.Settings) }) { Icon(Icons.Default.Settings, "Settings") }
        }
        Box(Modifier.clickable { nav.navigate(Routes.Voice) }) {
            AiOrb(busy || speaking || listening, Modifier.size(180.dp))
        }
        Text("Orb dabayein aur voice se baat karein", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f), singleLine = true,
                placeholder = { Text("Kuch poochiye…") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (input.isNotBlank()) { vm.send(input); input = ""; nav.navigate(Routes.Chat) }
                }),
            )
            FilledIconButton(onClick = {
                if (input.isNotBlank()) { vm.send(input); input = ""; nav.navigate(Routes.Chat) } else nav.navigate(Routes.Voice)
            }) {
                Icon(if (input.isBlank()) Icons.Default.Mic else Icons.AutoMirrored.Filled.Send, "Send or voice")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickCard(Icons.Default.ChatBubble, "Chat", Modifier.weight(1f)) { nav.navigate(Routes.Chat) }
            QuickCard(Icons.Default.Apps, "Apps", Modifier.weight(1f)) { nav.navigate(Routes.Launcher) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickCard(Icons.Default.MusicNote, "YouTube", Modifier.weight(1f)) { nav.navigate(Routes.Music) }
            QuickCard(Icons.Default.Code, "Coding", Modifier.weight(1f)) { nav.navigate(Routes.Coding) }
        }
        if (history.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Recent", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = { nav.navigate(Routes.History) }) { Text("See all") }
            }
            history.take(3).forEach { m ->
                Card(
                    Modifier.fillMaxWidth().clickable { vm.openConversation(m.id); nav.navigate(Routes.Chat) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) { Text(m.title, Modifier.padding(14.dp), maxLines = 1) }
            }
        }
    }
}

@Composable
private fun QuickCard(icon: ImageVector, title: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.titleMedium)
        }
    }
}

// ============================ 4. Voice ============================
@Composable
fun VoiceScreen(vm: AppViewModel, nav: NavController) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val msgs by vm.messages.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val speech by vm.speechState.collectAsStateWithLifecycle()
    val err by vm.error.collectAsStateWithLifecycle()
    val choices by vm.choices.collectAsStateWithLifecycle()
    val startMic = rememberMicStarter(vm)
    val export = rememberExporter()
    val listening = speech as? SpeechState.Listening
    Screen("Voice", { nav.popBackStack() }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            AiOrb(listening != null || speaking || busy, Modifier.size(200.dp))
            Waveform(listening != null || speaking)
            Text(
                when {
                    listening != null -> listening.partial.ifBlank { "Sun rahi hoon…" }
                    busy -> "Soch rahi hoon…"
                    speaking -> "Bol rahi hoon…"
                    else -> "Mic dabakar bolein. ${s.assistantName} sirf tabhi sunegi."
                },
                style = MaterialTheme.typography.titleMedium,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                if (listening != null) {
                    IconButton(onClick = { vm.cancelListening() }) { Icon(Icons.Default.Close, "Cancel") }
                    FilledIconButton(onClick = { vm.finishListening() }, Modifier.size(72.dp)) { Icon(Icons.Default.Stop, "Done") }
                } else {
                    FilledIconButton(onClick = startMic, Modifier.size(72.dp)) { Icon(Icons.Default.Mic, "Start listening") }
                }
                if (speaking) IconButton(onClick = { vm.stopSpeaking() }) { Icon(Icons.Default.Stop, "Stop speaking") }
            }
            msgs.lastOrNull { it.role == "user" }?.let { Text("Aapne: ${it.text}", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            msgs.lastOrNull()?.takeIf { it.role == "model" }?.let { Bubble(it, export) }
            if (choices.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                choices.forEach { AssistChip(onClick = { vm.launchChoice(it) }, label = { Text(it.label) }) }
            }
            err?.let { ErrorCard(it, { vm.retry() }, { nav.navigate(Routes.Gemini) }) }
            TextButton(onClick = { nav.navigate(Routes.Chat) }) { Text("Chat history dekhein") }
        }
    }
}

// ============================ 5. Chat ============================
@Composable
fun ChatScreen(vm: AppViewModel, nav: NavController) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val msgs by vm.messages.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val speech by vm.speechState.collectAsStateWithLifecycle()
    val err by vm.error.collectAsStateWithLifecycle()
    val choices by vm.choices.collectAsStateWithLifecycle()
    val startMic = rememberMicStarter(vm)
    val export = rememberExporter()
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val listening = speech as? SpeechState.Listening
    LaunchedEffect(msgs.size, busy) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }
    Screen(s.assistantName, { nav.popBackStack() }, actions = {
        if (speaking) IconButton(onClick = { vm.stopSpeaking() }) { Icon(Icons.Default.Stop, "Stop speaking") }
        IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "New chat") }
        IconButton(onClick = { nav.navigate(Routes.History) }) { Icon(Icons.Default.History, "History") }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            LazyColumn(
                Modifier.weight(1f), state = listState, contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (msgs.isEmpty()) item { Text("Namaste! Kuch bhi poochiye, ya bolein: \"open YouTube\", \"play Arijit Singh songs on YouTube\", \"Python ka code likho\".", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(msgs) { Bubble(it, export) }
                if (choices.isNotEmpty()) item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        choices.forEach { AssistChip(onClick = { vm.launchChoice(it) }, label = { Text(it.label) }) }
                    }
                }
                if (busy) item { CircularProgressIndicator(Modifier.size(24.dp)) }
                err?.let { e -> item { ErrorCard(e, { vm.retry() }, { nav.navigate(Routes.Gemini) }) } }
            }
            if (listening != null) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(listening.partial.ifBlank { "Sun rahi hoon…" }, Modifier.weight(1f))
                    TextButton(onClick = { vm.cancelListening() }) { Text("Cancel") }
                }
                Waveform(true, Modifier.fillMaxWidth().height(36.dp).padding(horizontal = 12.dp))
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    input, { input = it }, Modifier.weight(1f), maxLines = 4, placeholder = { Text("Message…") },
                )
                IconButton(onClick = { if (listening != null) vm.finishListening() else startMic() }) {
                    Icon(if (listening != null) Icons.Default.Stop else Icons.Default.Mic, "Voice input")
                }
                IconButton(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank() && !busy) {
                    Icon(Icons.AutoMirrored.Filled.Send, "Send")
                }
            }
        }
    }
}
