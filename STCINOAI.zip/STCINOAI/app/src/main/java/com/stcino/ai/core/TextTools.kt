package com.stcino.ai.core

data class Seg(val code: Boolean, val lang: String, val text: String)

object TextTools {
    private val fence = Regex("```([A-Za-z0-9+#_-]*)\\n?([\\s\\S]*?)```")

    /** Splits a model reply into plain-text and fenced-code segments. */
    fun segments(t: String): List<Seg> {
        val out = mutableListOf<Seg>()
        var last = 0
        for (m in fence.findAll(t)) {
            if (m.range.first > last) out += Seg(false, "", t.substring(last, m.range.first))
            out += Seg(true, m.groupValues[1], m.groupValues[2].trimEnd())
            last = m.range.last + 1
        }
        if (last < t.length) out += Seg(false, "", t.substring(last))
        return out.filter { it.code || it.text.isNotBlank() }
    }

    /** Removes markdown noise and code so TTS doesn't read symbols aloud. */
    fun forSpeech(t: String): String =
        t.replace(fence, " Code screen par hai. ")
            .replace(Regex("[*#`_>]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun extFor(lang: String): String = when (lang.lowercase()) {
        "python", "py" -> "py"
        "javascript", "js", "node", "nodejs" -> "js"
        "typescript", "ts" -> "ts"
        "tsx" -> "tsx"
        "jsx" -> "jsx"
        "html" -> "html"
        "css" -> "css"
        "java" -> "java"
        "kotlin", "kt" -> "kt"
        "sql" -> "sql"
        "json" -> "json"
        "xml" -> "xml"
        "bash", "sh", "shell" -> "sh"
        else -> "txt"
    }
}
