@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.stcino.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.stcino.ai.ai.AiResult
import com.stcino.ai.ai.ErrKind
import com.stcino.ai.core.TextTools
import com.stcino.ai.data.ChatMsg
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun Screen(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = actions,
            )
        },
        content = content,
    )
}

/** Animated AI orb. `active` speeds up the pulse (listening / thinking / speaking). */
@Composable
fun AiOrb(active: Boolean, modifier: Modifier = Modifier.size(160.dp)) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(if (active) 600 else 2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    Canvas(modifier) {
        val r = size.minDimension / 2
        drawCircle(
            Brush.radialGradient(listOf(Cyan.copy(alpha = 0.35f), Color.Transparent), center, r),
            radius = r * pulse, center = center,
        )
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFF67E8F9), Blue, Color(0xFF1E3A8A)),
                center = Offset(center.x - r * 0.15f, center.y - r * 0.15f), radius = r * 0.6f,
            ),
            radius = r * 0.55f * (if (active) pulse else 1f), center = center,
        )
    }
}

@Composable
fun Waveform(active: Boolean, modifier: Modifier = Modifier.fillMaxWidth().height(56.dp)) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "phase",
    )
    Canvas(modifier) {
        val n = 28
        val w = size.width / (n * 2f)
        for (i in 0 until n) {
            val amp = if (active) 0.25f + 0.75f * abs(sin(phase + i * 0.5f)) else 0.08f
            val h = size.height * amp
            drawRoundRect(
                Cyan, topLeft = Offset(i * 2 * w + w / 2, (size.height - h) / 2),
                size = Size(w, h), cornerRadius = CornerRadius(w / 2),
            )
        }
    }
}

@Composable
fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach {
            FilterChip(selected = it == selected, onClick = { onSelect(it) }, label = { Text(label(it)) })
        }
    }
}

// ---------------- code rendering ----------------
object Highlighter {
    private val kw = setOf(
        "def", "class", "import", "from", "return", "if", "else", "elif", "for", "while", "fun", "val", "var",
        "function", "const", "let", "public", "private", "static", "void", "int", "String", "new", "try", "catch",
        "except", "null", "None", "true", "false", "True", "False", "in", "is", "not", "and", "or", "when",
        "object", "interface", "package", "override", "async", "await", "export", "default",
        "SELECT", "FROM", "WHERE", "INSERT", "UPDATE", "DELETE", "JOIN", "CREATE", "TABLE",
    )
    private val re = Regex(
        "(//.*|#.*)|(\"(?:[^\"\\\\]|\\\\.)*\"|'(?:[^'\\\\]|\\\\.)*')|\\b(\\d+(?:\\.\\d+)?)\\b|\\b([A-Za-z_][A-Za-z0-9_]*)\\b"
    )

    fun highlight(code: String): AnnotatedString = buildAnnotatedString {
        var last = 0
        for (m in re.findAll(code)) {
            append(code.substring(last, m.range.first))
            val color = when {
                m.groups[1] != null -> Color(0xFF6B7A90)
                m.groups[2] != null -> Color(0xFFA5D6A7)
                m.groups[3] != null -> Color(0xFFFFB86C)
                m.value in kw -> Color(0xFF7DD3FC)
                else -> null
            }
            if (color != null) withStyle(SpanStyle(color = color)) { append(m.value) } else append(m.value)
            last = m.range.last + 1
        }
        append(code.substring(last))
    }
}

@Composable
fun CodeBlock(lang: String, code: String, onExport: (String, String) -> Unit) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF0B1220))) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(lang.ifBlank { "code" }, color = Cyan, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                clip.setText(AnnotatedString(code))
                Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
            }) { Icon(Icons.Default.ContentCopy, "Copy code", tint = Color(0xFFA9B7CC)) }
            IconButton(onClick = { onExport(code, lang) }) { Icon(Icons.Default.Save, "Save as file", tint = Color(0xFFA9B7CC)) }
        }
        Text(
            Highlighter.highlight(code), color = Color(0xFFE2E8F0), fontFamily = FontFamily.Monospace, fontSize = 13.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(12.dp),
        )
    }
}

@Composable
fun RichText(text: String, onExport: (String, String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        TextTools.segments(text).forEach { s ->
            if (s.code) CodeBlock(s.lang, s.text, onExport)
            else Text(s.text.trim().replace("**", ""))
        }
    }
}

@Composable
fun Bubble(m: ChatMsg, onExport: (String, String) -> Unit) {
    val mine = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Box(Modifier.padding(12.dp)) {
                if (mine) Text(m.text, color = MaterialTheme.colorScheme.onPrimary)
                else RichText(m.text, onExport)
            }
        }
    }
}

@Composable
fun ErrorCard(err: AiResult.Err, onRetry: () -> Unit, onOpenSettings: (() -> Unit)?) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(err.message, color = MaterialTheme.colorScheme.error)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (err.kind != ErrKind.NO_KEY && err.kind != ErrKind.INVALID_KEY) Button(onClick = onRetry) { Text("Retry") }
                if (onOpenSettings != null && (err.kind == ErrKind.NO_KEY || err.kind == ErrKind.INVALID_KEY)) {
                    Button(onClick = onOpenSettings) { Text("Gemini settings") }
                }
            }
        }
    }
}

// ---------------- helpers ----------------
/** Saves code via the system file picker (no storage permission needed). */
@Composable
fun rememberExporter(): (String, String) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(pending.toByteArray(Charsets.UTF_8)) }
                true
            } catch (e: Exception) { false }
            Toast.makeText(ctx, if (ok) "File save ho gayi" else "Save fail hua", Toast.LENGTH_SHORT).show()
        }
    }
    return { code, lang ->
        pending = code
        launcher.launch("code." + TextTools.extFor(lang))
    }
}

/** Returns a click handler for mic buttons: explains permission, asks only on tap, then listens. */
@Composable
fun rememberMicStarter(vm: AppViewModel): () -> Unit {
    val ctx = LocalContext.current
    var explain by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startListening() else vm.notice("Microphone permission nahi mili. Voice ke bina text se chat kar sakte hain.")
    }
    if (explain) {
        AlertDialog(
            onDismissRequest = { explain = false },
            title = { Text("Microphone permission") },
            text = { Text("Aapki awaaz sirf tab record hoti hai jab aap mic button dabate hain, taaki use text me badla ja sake. App kabhi background me nahi sunta.") },
            confirmButton = { TextButton(onClick = { explain = false; launcher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { explain = false }) { Text("Not now") } },
        )
    }
    return {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.startListening()
        else { explain = true }
    }
}
