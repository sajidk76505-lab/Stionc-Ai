package com.stcino.ai.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** One JSON file per conversation inside the app's private storage (filesDir/conversations). */
class HistoryRepository(ctx: Context) {
    private val dir = File(ctx.filesDir, "conversations").apply { mkdirs() }

    private fun file(id: String) =
        File(dir, id.filter { it.isLetterOrDigit() || it == '-' } + ".json")

    suspend fun list(): List<ConversationMeta> = withContext(Dispatchers.IO) {
        dir.listFiles { f -> f.extension == "json" }.orEmpty().mapNotNull { f ->
            runCatching {
                val c = Conversation.fromJson(f.readText())
                ConversationMeta(c.id, c.title, c.updated, c.messages.size)
            }.getOrNull()
        }.sortedByDescending { it.updated }
    }

    suspend fun load(id: String): Conversation? = withContext(Dispatchers.IO) {
        runCatching { Conversation.fromJson(file(id).readText()) }.getOrNull()
    }

    suspend fun save(c: Conversation) = withContext(Dispatchers.IO) {
        val target = file(c.id)
        val tmp = File(dir, target.name + ".tmp")
        tmp.writeText(c.toJson())
        if (!tmp.renameTo(target)) {
            target.writeText(c.toJson())
            tmp.delete()
        }
    }

    suspend fun rename(id: String, title: String) {
        val c = load(id) ?: return
        save(c.copy(title = title))
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) { file(id).delete(); Unit }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        dir.listFiles().orEmpty().forEach { it.delete() }
    }
}
