package com.stcino.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF22D3EE)
val Blue = Color(0xFF3B82F6)
val Ink = Color(0xFF070B14)

private val DarkC = darkColorScheme(
    primary = Cyan, onPrimary = Ink, secondary = Blue,
    background = Ink, onBackground = Color(0xFFE6EDF7),
    surface = Color(0xFF111A2B), onSurface = Color(0xFFE6EDF7),
    surfaceVariant = Color(0xFF18243A), onSurfaceVariant = Color(0xFFA9B7CC),
    error = Color(0xFFFF6B6B),
)
private val LightC = lightColorScheme(
    primary = Color(0xFF0284C7), onPrimary = Color.White, secondary = Blue,
    background = Color(0xFFF4F8FC), onBackground = Color(0xFF0B1220),
    surface = Color.White, onSurface = Color(0xFF0B1220),
    surfaceVariant = Color(0xFFE3EBF6), onSurfaceVariant = Color(0xFF42536B),
)

@Composable
fun StcinoTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "light" -> false
        "system" -> isSystemInDarkTheme()
        else -> true
    }
    MaterialTheme(colorScheme = if (dark) DarkC else LightC, content = content)
}
