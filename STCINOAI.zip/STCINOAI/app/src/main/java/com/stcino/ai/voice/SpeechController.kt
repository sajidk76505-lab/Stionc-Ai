package com.stcino.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class SpeechState {
    object Idle : SpeechState()
    data class Listening(val partial: String) : SpeechState()
    data class Error(val message: String) : SpeechState()
}

/**
 * Wraps android.speech.SpeechRecognizer. One utterance per user tap: there is NO continuous or
 * background listening. Must be called on the main thread (the ViewModel does this).
 */
class SpeechController(private val ctx: Context) {
    private var rec: SpeechRecognizer? = null
    private val _state = MutableStateFlow<SpeechState>(SpeechState.Idle)
    val state: StateFlow<SpeechState> = _state.asStateFlow()

    fun isAvailable() = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun start(langTag: String, onText: (String) -> Unit) {
        if (!isAvailable()) {
            _state.value = SpeechState.Error("Is device par speech recognition service nahi mili. Text se type karein.")
            return
        }
        cancel()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _state.value = SpeechState.Listening("") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (_state.value is SpeechState.Listening) _state.value = SpeechState.Listening(p)
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                _state.value = SpeechState.Idle
                release()
                if (!t.isNullOrBlank()) onText(t)
            }
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch sunai nahi diya. Dobara try karein."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission chahiye."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service ke liye internet chahiye ho sakta hai."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai, thodi der baad try karein."
                    else -> "Voice input fail hua (code $error)."
                }
                release()
                _state.value = SpeechState.Error(msg)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        r.startListening(i)
    }

    /** User is done talking: process what was heard. */
    fun finish() { rec?.stopListening() }

    /** Cancel button: discard everything. */
    fun cancel() {
        release()
        if (_state.value is SpeechState.Listening) _state.value = SpeechState.Idle
    }

    fun reset() { if (_state.value is SpeechState.Error) _state.value = SpeechState.Idle }

    private fun release() {
        rec?.let { runCatching { it.cancel() }; runCatching { it.destroy() } }
        rec = null
    }
}
