# STCINO AI — Personal Jarvis-style Android assistant

Kotlin + Jetpack Compose, Gemini REST API, no paid SDKs. Package: `com.stcino.ai` · minSdk 26 · targetSdk 34.

## Status (honest)
- Source code is complete but was **NOT compiled or run** where it was written (no Android SDK / network there).
  First build may show small compile errors; send the log and they get fixed.
- Unit tests (parser, matcher, Gemini parsing, validators, history JSON) exist but have **not been run yet**.

## What works
| Needs nothing | Needs Gemini key | Needs permission | Not in v1 |
|---|---|---|---|
| App launcher, YouTube search, history, themes, name/personality | Chat, coding assistant, voice replies | Mic (only on tap) | AccessibilityService touch automation |

- Voice commands are rule-parsed (English / Hinglish / Hindi): "open YouTube", "Chrome open karo", "search GTA V gameplay", "Hindi mein jawab do". Everything else goes to Gemini.
- "play X" / "search X" are treated as YouTube searches.
- Speech recognition uses Android's `SpeechRecognizer`; on many phones it needs Google's speech service (may use internet).
- Launcher label can't be renamed at runtime by Android. The in-app name changes instantly; Settings → Customization can pin a home-screen shortcut with your custom name.
- API key: AES-256-GCM, key held in Android Keystore. A client-side key can still be extracted on a rooted/reverse-engineered device; for public release put a backend proxy in front of Gemini.
- Free quota / model access depend on Google's current terms. Models are fetched live via "Test connection"; default id `gemini-2.5-flash` is editable.
- Generated code is never executed. Terminal commands are only explained.

## Structure
```
app/src/main/java/com/stcino/ai/
  ai/     AiProvider (interface), GeminiProvider, GeminiParser
  core/   CommandParser, AppMatcher, AppRepository, YouTube, TextTools, PromptBuilder, CodeAssist, Validators, Shortcuts
  data/   Models, SettingsStore (DataStore), SecureKey (Keystore), HistoryRepository (JSON files)
  voice/  SpeechController, TtsController
  ui/     Theme, Components, AppViewModel, Nav, Screens1-3
app/src/test/...  unit tests
.github/workflows/build.yml  CI build → debug APK
```
See `BUILD_TERMUX.md` to build.
