# Building from a phone (Termux)

## Reality check
Google's Android build tools (`aapt2`, SDK platform) are x86 Linux binaries. On ARM Termux a full local
Gradle build is **fragile/experimental**. The reliable free path is **Option A: GitHub Actions**
(Termux just pushes the code; GitHub builds the APK). Nothing below means "a build succeeded" until
you actually see an APK file.

## Option A — recommended (Termux + GitHub Actions)

1. Check environment and storage:
```
termux-info | head -5
df -h $HOME | tail -1
```
2. Install git and unzip:
```
pkg update -y && pkg install -y git unzip
```
3. Allow storage access, then unzip the project (adjust the path where you saved the zip):
```
termux-setup-storage
cd ~ && unzip /sdcard/Download/STCINOAI.zip && cd STCINOAI
ls
```
You should see `app`, `build.gradle.kts`, `settings.gradle.kts`, `.github`.

4. On github.com (phone browser) create an empty repo, e.g. `stcino-ai` (no README). Create a Personal Access Token
   (Settings → Developer settings → Tokens, "repo" scope).
5. Push:
```
git init -b main
git add -A
git commit -m "STCINO AI initial"
git remote add origin https://github.com/<your-user>/stcino-ai.git
git push -u origin main
```
(username = your GitHub user, password = the token.)

6. Open the repo → **Actions** tab → "Build debug APK" → when green, open the run → **Artifacts** →
   download `stcino-debug-apk` (zip containing `app-debug.apk`).
7. Verify the file exists, then install:
```
ls -l /sdcard/Download/*.zip
cd /sdcard/Download && unzip -o stcino-debug-apk.zip && ls -l app-debug.apk
```
Open `app-debug.apk` from your file manager and allow "Install unknown apps" for that file manager.

If the run is red: open the failed step, copy the error lines and send them to me.

## Option B — local build in Termux (experimental)
Requires ~3 GB free. Inspect first:
```
uname -m
pkg search aapt2
pkg search openjdk-17
pkg search gradle
```
Possible route (only if those packages exist for your device):
```
pkg install -y openjdk-17 gradle aapt2
```
You also need an Android SDK with `platforms;android-34` (android.jar) and `build-tools`, and must point Gradle at
Termux's ARM `aapt2` by adding to `gradle.properties`:
```
android.aapt2FromMavenOverride=/data/data/com.termux/files/usr/bin/aapt2
```
and creating `local.properties` with `sdk.dir=<your sdk path>`. Then:
```
gradle :app:testDebugUnitTest :app:assembleDebug --no-daemon
ls -l app/build/outputs/apk/debug/app-debug.apk
```
No Gradle wrapper jar is bundled (binary, couldn't be downloaded offline), so use the `gradle` command.
If this fails with aapt2/SDK errors, use Option A.

## Common failures
- `SDK location not found` → create `local.properties` (Option B) or ignore (Actions has the SDK).
- `Unsupported class file major version` → JDK must be 17.
- `aapt2 ... Syntax error / cannot execute` → x86 binary on ARM → use Option A.
- Compile error in a Kotlin file → send me the error lines.
- Mic not working → Settings → Apps → STCINO AI → Permissions → Microphone; also install a speech service (Google).
